package com.nyxei.pollingus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PollingusApplicationTests {

	@Test
	void contextLoads() {
	}

}
