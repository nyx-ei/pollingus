package com.nyxei.pollingus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PollingusApplication {

	public static void main(String[] args) {
		SpringApplication.run(PollingusApplication.class, args);
	}

}
